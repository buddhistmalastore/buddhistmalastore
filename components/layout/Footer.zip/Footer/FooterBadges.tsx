"use client";

import {
  FaHandsHelping,
  FaGlobeAsia,
  FaLock,
} from "react-icons/fa";

const badges = [
  {
    icon: FaHandsHelping,
    title: "Handmade in Nepal",
  },
  {
    icon: FaGlobeAsia,
    title: "Worldwide Shipping",
  },
  {
    icon: FaLock,
    title: "Secure Payments",
  },
];

export default function FooterBadges() {
  return (
    <div className="flex flex-wrap justify-center gap-6">

      {badges.map((badge) => {
        const Icon = badge.icon;

        return (
          <div
            key={badge.title}
            className="
              group
              flex
              items-center
              gap-4
              rounded-full
              border
              border-[#D4AF3730]
              bg-white/40
              px-8
              py-4
              transition-all
              duration-300
              hover:border-[#D4AF37]
              hover:shadow-[0_10px_25px_rgba(212,175,55,.15)]
            "
          >
            <div
              className="
                flex
                h-10
                w-10
                items-center
                justify-center
                rounded-full
                border
                border-[#D4AF37]
                text-[#D4AF37]
                transition
                group-hover:bg-[#D4AF37]
                group-hover:text-white
              "
            >
              <Icon size={16} />
            </div>

            <span className="text-[15px] text-[#444]">
              {badge.title}
            </span>
          </div>
        );
      })}

    </div>
  );
}