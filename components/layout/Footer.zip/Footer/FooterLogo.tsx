"use client";

import Image from "next/image";
import Link from "next/link";

import { socialLinks, footerInfo } from "./footerData";

export default function FooterLogo() {
  return (
    <div className="flex flex-col items-center text-center">

      {/* Dharma Divider */}

      <div className="relative flex w-full items-center justify-center mb-10">

        <div className="absolute left-0 h-px w-[42%] bg-[#D4AF3730]" />

        <div className="relative z-10 bg-[#F8F3EB] px-6">

          <Image
            src="/icons/dharma-wheel.png"
            alt="Dharma Wheel"
            width={40}
            height={40}
          />

        </div>

        <div className="absolute right-0 h-px w-[42%] bg-[#D4AF3730]" />

      </div>

      {/* Logo */}

      <Link
        href="/"
        className="transition duration-500 hover:scale-105"
      >
        <Image
          src="/logo.png"
          alt={footerInfo.brand}
          width={165}
          height={165}
          priority
        />
      </Link>

      {/* Brand */}

      <h2
        className="
          heading-font
          mt-8
          text-5xl
          leading-none
          text-[#231A12]
        "
      >
        {footerInfo.brand}
      </h2>

      <p
        className="
          mt-3
          text-[22px]
          text-[#B7861C]
        "
      >
        {footerInfo.subtitle}
      </p>

      {/* Gold Divider */}

      <div
        className="
          mt-6
          h-px
          w-24
          bg-[#D4AF37]
        "
      />

      {/* Tagline */}

      <p
        className="
          mt-6
          max-w-xl
          text-sm
          leading-7
          tracking-[3px]
          uppercase
          text-[#7A746D]
        "
      >
        {footerInfo.tagline}
      </p>

      {/* Social */}

      <div className="mt-10 flex items-center gap-4">

        {socialLinks.map((item) => {
          const Icon = item.icon;

          return (
            <Link
              key={item.title}
              href={item.href}
              target="_blank"
              aria-label={item.title}
              className="
                flex
                h-11
                w-11
                items-center
                justify-center
                rounded-full
                border
                border-[#D4AF37]
                text-[#D4AF37]
                transition-all
                duration-300
                hover:bg-[#D4AF37]
                hover:text-white
                hover:shadow-[0_0_18px_rgba(212,175,55,.35)]
              "
            >
              <Icon size={17} />
            </Link>
          );
        })}

      </div>

    </div>
  );
}