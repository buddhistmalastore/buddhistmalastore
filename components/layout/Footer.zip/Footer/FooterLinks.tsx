"use client";

import Link from "next/link";
import { FooterLink } from "./types";

interface Props {
  title: string;
  links: FooterLink[];
}

export default function FooterLinks({
  title,
  links,
}: Props) {
  return (
    <div className="text-center md:text-left">

      {/* Heading */}

      <h3
        className="
          heading-font
          text-3xl
          text-[#231A12]
        "
      >
        {title}
      </h3>

      <div
        className="
          mx-auto
          md:mx-0
          mt-3
          mb-8
          h-[2px]
          w-12
          bg-[#D4AF37]
        "
      />

      {/* Links */}

      <ul className="space-y-5">

        {links.map((link) => (
          <li key={link.title}>

            <Link
              href={link.href}
              className="
                group
                inline-flex
                items-center
                text-[15px]
                text-[#555]
                transition-all
                duration-300
                hover:text-[#D4AF37]
              "
            >
              <span
                className="
                  mr-0
                  w-0
                  overflow-hidden
                  text-[#D4AF37]
                  transition-all
                  duration-300
                  group-hover:mr-3
                  group-hover:w-4
                "
              >
                →
              </span>

              <span
                className="
                  relative
                  after:absolute
                  after:left-0
                  after:-bottom-1
                  after:h-px
                  after:w-0
                  after:bg-[#D4AF37]
                  after:transition-all
                  after:duration-300
                  group-hover:after:w-full
                "
              >
                {link.title}
              </span>

            </Link>

          </li>
        ))}

      </ul>

    </div>
  );
}