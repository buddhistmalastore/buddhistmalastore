"use client";

import {
  FaMapMarkerAlt,
  FaEnvelope,
  FaPhoneAlt,
} from "react-icons/fa";

import { footerInfo } from "./footerData";

export default function FooterContact() {
  return (
    <div className="text-center md:text-left">

      <h3
        className="
          heading-font
          text-3xl
          text-[#231A12]
        "
      >
        Contact
      </h3>

      <div
        className="
          mx-auto
          md:mx-0
          mt-3
          mb-8
          h-[2px]
          w-12
          bg-[#D4AF37]
        "
      />

      <div className="space-y-6">

        {/* Address */}

        <div className="flex items-start gap-4 justify-center md:justify-start">

          <div className="mt-1 text-[#D4AF37]">
            <FaMapMarkerAlt />
          </div>

          <p className="text-[#555] leading-7">
            {footerInfo.address}
          </p>

        </div>

        {/* Email */}

        <div className="flex items-center gap-4 justify-center md:justify-start">

          <FaEnvelope className="text-[#D4AF37]" />

          <a
            href={`mailto:${footerInfo.email}`}
            className="
              text-[#555]
              transition
              hover:text-[#D4AF37]
            "
          >
            {footerInfo.email}
          </a>

        </div>

        {/* Phone */}

        <div className="flex items-center gap-4 justify-center md:justify-start">

          <FaPhoneAlt className="text-[#D4AF37]" />

          <a
            href={`tel:${footerInfo.phone}`}
            className="
              text-[#555]
              transition
              hover:text-[#D4AF37]
            "
          >
            {footerInfo.phone}
          </a>

        </div>

      </div>

    </div>
  );
}