"use client";

import Image from "next/image";

export default function FooterBottom() {
  return (
    <section className="py-10">

      {/* Divider */}

      <div className="relative flex items-center justify-center">

        <div className="absolute left-0 h-px w-[44%] bg-[#D4AF3730]" />

        <div className="relative z-10 bg-[#F8F3EB] px-5">

          <Image
            src="/icons/dharma-wheel.png"
            alt="Dharma Wheel"
            width={34}
            height={34}
          />

        </div>

        <div className="absolute right-0 h-px w-[44%] bg-[#D4AF3730]" />

      </div>

      {/* Copyright */}

      <div className="mt-8 text-center">

        <p className="text-sm text-[#666]">
          © 2026 Buddhist Mala Store. All Rights Reserved.
        </p>

        <p
          className="
            mt-3
            text-[11px]
            uppercase
            tracking-[5px]
            text-[#D4AF37]
          "
        >
          Crafted with Devotion in Nepal
        </p>

      </div>

    </section>
  );
}