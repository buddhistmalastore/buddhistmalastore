"use client";

import Image from "next/image";

const methods = [
  "visa",
  "mastercard",
  "paypal",
  "stripe",
];

export default function FooterPayments() {
  return (
    <div className="flex justify-center">

      <div className="flex flex-wrap items-center justify-center gap-10">

        {methods.map((item) => (
          <Image
            key={item}
            src={`/icons/${item}.svg`}
            alt={item}
            width={60}
            height={34}
            className="
              opacity-70
              grayscale
              transition-all
              duration-300
              hover:opacity-100
              hover:grayscale-0
              hover:scale-110
            "
          />
        ))}

      </div>

    </div>
  );
}