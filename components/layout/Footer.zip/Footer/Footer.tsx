"use client";

import FooterLogo from "./FooterLogo";
import FooterLinks from "./FooterLinks";
import FooterContact from "./FooterContact";
import FooterBadges from "./FooterBadges";
import FooterPayments from "./FooterPayments";
import FooterBottom from "./FooterBottom";

import {
  shopLinks,
  supportLinks,
} from "./footerData";

export default function Footer() {
  return (
    <footer
      className="
        relative
        overflow-hidden
        bg-[#F8F3EB]
        border-t
        border-[#D4AF3715]
      "
    >
      {/* Decorative Background */}

      <div
        className="
          absolute
          inset-0
          pointer-events-none
        "
      >
        <div
          className="
            absolute
            left-1/2
            top-24
            -translate-x-1/2
            opacity-[0.03]
          "
        >
          {/* We'll replace this with the Dharma Wheel later */}
        </div>
      </div>

      <div
        className="
          relative
          mx-auto
          max-w-7xl
          px-6
          lg:px-10
        "
      >
        {/* ================================================= */}
        {/* LOGO SECTION */}
        {/* ================================================= */}

        <section className="pt-20 pb-16">

          <FooterLogo />

        </section>

        {/* ================================================= */}
        {/* NAVIGATION */}
        {/* ================================================= */}

        <section
          className="
            border-t
            border-[#D4AF3720]
            py-14
          "
        >
          <div
            className="
              grid
              gap-12
              md:grid-cols-3
            "
          >
            <FooterLinks
              title="Shop"
              links={shopLinks}
            />

            <FooterLinks
              title="Support"
              links={supportLinks}
            />

            <FooterContact />

          </div>

        </section>

        {/* ================================================= */}
        {/* TRUST */}
        {/* ================================================= */}

        <section
          className="
            border-t
            border-[#D4AF3720]
            py-10
          "
        >
          <FooterBadges />
        </section>

        {/* ================================================= */}
        {/* PAYMENTS */}
        {/* ================================================= */}

        <section
          className="
            border-t
            border-[#D4AF3720]
            py-10
          "
        >
          <FooterPayments />
        </section>

        {/* ================================================= */}
        {/* COPYRIGHT */}
        {/* ================================================= */}

        <FooterBottom />

      </div>

    </footer>
  );
}